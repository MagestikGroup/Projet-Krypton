import mongoose from "mongoose";
import moment from "moment";

const Schema = mongoose.Schema;

const bookingSchema = new mongoose.Schema({
  userId: {
    type: Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },

  transactionId: {
    type: String,
    required: true,
  },


  formula: {
    type: String,
    required: true,
  },

  selectedDate: {
    type: String,
    required: true,
  },

  peopleNumber: {
    type: String,
    required: true,
  },

  selectedDecor: {
    type: String,
    required: true,
  },
 
  timeSlot: {
    type: String,
    required: true,
  },

  sessionDuration: {
    type: String,
    required: true,
  },

  nomEntreprise: {
    type: String
  },

  address: {
    type: String
  },
 
  createdAt: {
    type: Date,
    default: Date.now,
  },
});

export const Booking = mongoose.model("Booking", bookingSchema);
