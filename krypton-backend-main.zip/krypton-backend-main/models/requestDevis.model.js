import mongoose from "mongoose";

const devisSchema = new mongoose.Schema({
  fullName: { type: String },
  phone: { type: String },
  email: { type: String },
  secteurActivite: { type: String },
  livestream: { type: String },
  other: { type: String },
  dureeEvenement: { type: String },
  nombrePersonnes: { type: Number },
  nombreIntervenantsDistant: { type: Number },
  typeCanal: {
    type: [String],
  },
  typeEvenement: { type: String },
  ifOther: { type: String },
  date: { type: Date },
  descriptionEvenement: { type: String },
  nomEntreprise: { type: String },
  typeProduit: { type: String },
  typePresentation: { type: String },
  nombreEpisode: { type: Number },
  frequence: { type: Number },
  nmbreSemaine: { type: String },
  nmbreMois: { type: String },
  quotationType: {
    type: String,
    require: true,
    enum: ["business", "livestream"],
    default: "business",
  },
  createdAt: { type: Date, default: Date.now },
});

export const Devis = mongoose.model("Devis", devisSchema);
