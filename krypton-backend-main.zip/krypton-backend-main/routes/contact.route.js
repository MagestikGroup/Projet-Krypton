import express from "express";
import {
  createContact,
  getContact,
  getAllContact,
  deleteContact,
} from "../controllers/contact.controller.js";

const router = express.Router();

router.post("/contacts", createContact);

router.get("/contacts", getAllContact);
router.get("/contacts/:contactId", getContact);

router.delete("/contacts/:contactId", deleteContact);

export default router;
