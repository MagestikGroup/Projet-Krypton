import express from "express";
import {
  signup,
  updateAdmin,
  deleteAdmin,
  createSuperAdmin,
  deleteSuperAdmin,
  blockAdmin,
  unblockAdmin,
  getAllAdmins,
  getAdminById,
  login,
} from "../controllers/authAdmin.controller.js";
import { isAuthenticated, isSuperAdmin } from "../middleware/adminAuth.js";

const router = express.Router();

router.post("/signup", isAuthenticated, isSuperAdmin, signup);

router.put("/update/:id", isAuthenticated, isSuperAdmin, updateAdmin);

router.delete("/delete/:id", isAuthenticated, isSuperAdmin, deleteAdmin);

router.get("/admins", isAuthenticated, getAllAdmins);

router.get("/admins/:id", isAuthenticated, getAdminById);

router.post("/create-super-admin", createSuperAdmin);

router.delete(
  "/delete-super-admin/:id",
  isAuthenticated,
  isSuperAdmin,
  deleteSuperAdmin
);
router.patch("/block/:id", isAuthenticated, isSuperAdmin, blockAdmin);

router.patch("/unblock/:id", isAuthenticated, isSuperAdmin, unblockAdmin);

router.post("/login", login);

export default router;
