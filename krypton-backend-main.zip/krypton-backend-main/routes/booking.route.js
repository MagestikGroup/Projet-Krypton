import express from "express";
import {
  createBooking,
  getUserBookings,
  deleteBooking,
  getUserBookingsByAdmin,
  updateBooking,
  unavailableSlot,
  getBookingByIdByUserId,
} from "../controllers/booking.controller.js";

const router = express.Router();

router.post("/booking", createBooking);
router.get("/user/bookings", getUserBookings);
router.get("/admin/bookings/:userId", getUserBookingsByAdmin);
router.get("/admin/booking/:bookingId/:userId", getBookingByIdByUserId);
router.delete("/booking/:bookingId", deleteBooking);
router.get("/unavailable-slot/:date", unavailableSlot);
router.put("/booking/:bookingId", updateBooking);

export default router;
