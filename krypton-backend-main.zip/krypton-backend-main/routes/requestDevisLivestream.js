import express from "express";
import {
  createDevis,
  getDevis,
  getAllDevis,
  deleteDevis,
} from "../controllers/requestDevisLivestream.controller.js";

const router = express.Router();

router.post("/devis-livestream", createDevis);
router.get("/devis/:devisId", getDevis);
router.get("/devis", getAllDevis);
router.delete("/devis/:devisId", deleteDevis);

export default router;
