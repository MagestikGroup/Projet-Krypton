import bcryptjs from "bcryptjs";
import crypto from "crypto";
import jwt from "jsonwebtoken";
import {
  sendPasswordResetEmail,
  sendResetSuccessEmail,
  sendVerificationEmail,
  sendWelcomeEmail,
} from "../mailJet/emails.js";
import { User } from "../models/user.model.js";

export const signup = async (req, res) => {
  const { email, password, firstName, phone, lastName } = req.body;

  try {
    if (!email || !password || !firstName || !lastName || !phone) {
      throw new Error("All fields are required");
    }

    const userAlreadyExists = await User.findOne({ email });

    if (userAlreadyExists) {
      return res
        .status(409)
        .json({ success: false, message: "User already exists" });
    }

    const hashedPassword = await bcryptjs.hash(password, 10);
    const verificationToken = Math.floor(
      100000 + Math.random() * 900000
    ).toString();

    let user = new User({
      email,
      password: hashedPassword,
      firstName,
      lastName,
      phone,
      verificationToken,
      verificationTokenExpiresAt: Date.now() + 24 * 60 * 60 * 1000, // 24 hours
    });

    user = await user.save();
    const accessToken = jwt.sign(
      { _id: user._id.toString() },
      process.env.JWT_SECRET,
      {
        expiresIn: "7d", // Token valid for 7 days
      }
    );

    user.tokens = user.tokens.concat({ accessToken });
    await user.save();

    await sendVerificationEmail(user.email, verificationToken);
    console.log("Verif Code", verificationToken);

    res.status(201).json({
      success: true,
      message: "User created successfully",
    });
  } catch (error) {
    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((val) => val.message);
      return res
        .status(400)
        .json({ success: false, message: messages.join(", ") });
    } else {
      res.status(400).json({ success: false, message: error.message });
    }
  }
};

export const verifyEmail = async (req, res) => {
  const { verificationCode } = req.body;
  try {
    const user = await User.findOne({
      verificationToken: verificationCode,
      verificationTokenExpiresAt: { $gt: Date.now() },
    });

    if (!user) {
      return res.status(410).json({
        success: false,
        message: "Invalid or expired verification code",
      });
    }

    user.isVerified = true;
    user.verificationToken = undefined;
    user.verificationTokenExpiresAt = undefined;
    await user.save();

    await sendWelcomeEmail(user.email, user.firstName);

    const accessToken =
      user.tokens.length > 0 ? user.tokens[0].accessToken : null;

    res.status(201).json({
      success: true,
      message: "Email verified successfully",
      accessToken,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) {
      return res
        .status(400)
        .json({ success: false, message: "Identifiant ou mot de pass incorrect" });
    }
    const isPasswordValid = await bcryptjs.compare(password, user.password);
    if (!isPasswordValid) {
      return res
        .status(400)
        .json({ success: false, message: "Identifiant ou mot de pass incorrect" });
    }

    user.lastLogin = new Date();
    await user.save();

    const accessToken = jwt.sign(
      { _id: user._id.toString() },
      process.env.JWT_SECRET,
      {
        expiresIn: "7d", // Token valid for 7 days
      }
    );

    user.tokens = user.tokens.concat({ accessToken });
    await user.save();

    res.status(200).json({
      success: true,
      message: "Logged in successfully",
      accessToken, // Return the token
    });
  } catch (error) {
    console.log("Error in login ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

export const logout = async (req, res) => {
  try {
    const token = req.headers["authorization"];

    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decodedToken._id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    // Clear the tokens array
    user.tokens = [];
    await user.save(); // Save the updated user without tokens

    res.status(200).json({ success: true, message: "Logged out successfully" });
    console.log(user)

  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const forgotPassword = async (req, res) => {
  const { email } = req.body;
  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res
        .status(400)
        .json({ success: false, message: "User not found" });
    }

    // Generate reset token
    const resetToken = crypto.randomBytes(20).toString("hex");
    const resetTokenExpiresAt = Date.now() + 1 * 60 * 60 * 1000; // 1 hour

    user.resetPasswordToken = resetToken;
    user.resetPasswordExpiresAt = resetTokenExpiresAt;

    await user.save();

    // send email
    await sendPasswordResetEmail(
      user.email,
      `${process.env.BASE_URL}/reset-password/${resetToken}`
    );

    res.status(200).json({
      success: true,
      message: "Password reset link sent to your email",
    });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const resetPassword = async (req, res) => {
  try {
    const { token } = req.params;
    const { password } = req.body;

    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpiresAt: { $gt: Date.now() },
    });

    if (!user) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid or expired reset token" });
    }

    // update password
    const hashedPassword = await bcryptjs.hash(password, 10);

    user.password = hashedPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpiresAt = undefined;
    await user.save();

    await sendResetSuccessEmail(user.email);

    res
      .status(200)
      .json({ success: true, message: "Password reset successful" });
  } catch (error) {
    res.status(400).json({ success: false, message: error.message });
  }
};

export const checkAuth = async (req, res) => {
  try {
    const user = await User.findById(req.userId).select("-password");
    if (!user) {
      return res
        .status(400)
        .json({ success: false, message: "User not found" });
    }

    res.status(200).json({ success: true, user });
  } catch (error) {
    console.log("Error in checkAuth ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

export const getUserInfo = async (req, res) => {
  try {
    const token = req.headers["authorization"];
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "No token provided" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decodedToken._id).select("-password");

    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    const validToken = user.tokens.some((t) => t.accessToken === token);

    if (!validToken) {
      return res
        .status(401)
        .json({ success: false, message: "Invalid access token" });
    }

    const userInfo = {
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
    };

    res.status(200).json({ success: true, user: userInfo });
  } catch (error) {
    console.log("Error in getUserInfo:", error);

    if (error.name === "JsonWebTokenError") {
      return res.status(401).json({ success: false, message: "Invalid token" });
    }

    if (error.name === "TokenExpiredError") {
      return res
        .status(401)
        .json({ success: false, message: "Token has expired" });
    }

    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const refreshUser = async (req, res) => {
  try {
    const token = req.headers["authorization"];
    
    if (!token) {
      return res.status(401).json({ success: false, message: "No token provided" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decodedToken._id);

    if (!user) {
      return res.status(404).json({ success: false, message: "User not found" });
    }

    // Check if the token exists in the user's tokens array
    const validToken = user.tokens.some((t) => t.accessToken === token);

    if (!validToken) {
      return res.status(401).json({ success: false, message: "Invalid access token" });
    }

    // Send back user information
    const userData = {
      _id: user._id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      phone: user.phone,
    };

    res.json({ success: true, user: userData });
  } catch (error) {
    res.status(401).json({ success: false, message: "Unauthorized or invalid token" });
  }
};


export const updateUser = async (req, res) => {
  const { email, phone, oldPassword, newPassword, firstName, lastName } =
    req.body;

  try {
    // Check if the user is trying to modify firstName or lastName
    if (firstName || lastName) {
      return res.status(400).json({
        success: false,
        message: "Modification of firstName and lastName is not allowed",
      });
    }

    // const token = req.headers["authorization"];

    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decodedToken._id);
    if (!user) {
      return res
        .status(404)
        .json({ success: false, message: "User not found" });
    }

    // Check if the user wants to update the password
    if (newPassword) {
      if (!oldPassword) {
        return res.status(400).json({
          success: false,
          message: "Current password is required to update password",
        });
      }

      const isPasswordValid = await bcryptjs.compare(
        oldPassword,
        user.password
      );
      if (!isPasswordValid) {
        return res
          .status(400)
          .json({ success: false, message: "Current password is incorrect" });
      }

      const hashedNewPassword = await bcryptjs.hash(newPassword, 10);
      user.password = hashedNewPassword;
    }

    if (email) user.email = email;
    if (phone) user.phone = phone;

    await user.save();

    res.status(200).json({
      success: true,
      message: "User updated successfully",
    });
  } catch (error) {
    console.log("Error in updateUser:", error);
    res.status(500).json({ success: false, message: error.message });
  }
};
