import Admin from "../models/admin.model.js";
import bcryptjs from "bcryptjs";
import jwt from "jsonwebtoken";

const generateAuthToken = async (admin) => {
  const accessToken = jwt.sign(
    { _id: admin._id.toString() },
    process.env.JWT_SECRET,
    { expiresIn: "7d" }
  );

  if (!admin.tokens) {
    admin.tokens = [];
  }

  admin.tokens = admin.tokens.concat({ accessToken });
  await admin.save();

  return accessToken;
};

// Connexion d'un administrateur
export const login = async (req, res) => {
  const { email, password } = req.body;

  try {
    const admin = await Admin.findOne({ email });
    if (!admin) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid credentials" });
    }

    if (admin.isBlocked) {
      return res
        .status(403)
        .json({ success: false, message: "Votre compte est bloqué" });
    }

    const isPasswordValid = await bcryptjs.compare(password, admin.password);
    if (!isPasswordValid) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid credentials" });
    }

    admin.lastLogin = new Date();
    await admin.save();

    const accessToken = await generateAuthToken(admin); // Note: Ensure `generateAuthToken` returns a promise

    res.status(200).json({
      success: true,
      message: "Logged in successfully",
      accessToken, // Renvoi du token dans la réponse
    });
  } catch (error) {
    console.log("Error in login ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Création d'un nouvel administrateur

export const signup = async (req, res) => {
  const { email, password, firstName, lastName, phone } = req.body;

  try {
    if (!email || !password || !firstName || !lastName || !phone) {
      throw new Error("All fields are required");
    }

    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    const adminAlreadyExists = await Admin.findOne({ email });
    if (adminAlreadyExists) {
      return res
        .status(409)
        .json({ success: false, message: "Admin already exists" });
    }

    const hashedPassword = await bcryptjs.hash(password, 10);

    let newAdmin = new Admin({
      email,
      password: hashedPassword,
      firstName,
      lastName,
      phone,
    });
    await newAdmin.save();

    const accessToken = generateAuthToken(newAdmin);

    res.status(201).json({
      success: true,
      message: "Admin created successfully",
      accessToken,
    });
  } catch (error) {
    console.log("Error in signup ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Mise à jour d'un administrateur
export const updateAdmin = async (req, res) => {
  const { email, phone, newPassword } = req.body;

  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    // Trouvez l'administrateur cible
    const targetAdmin = await Admin.findById(req.params.id);
    if (!targetAdmin) {
      return res
        .status(404)
        .json({ success: false, message: "Admin not found" });
    }

    if (email) targetAdmin.email = email;
    if (phone) targetAdmin.phone = phone;
    if (newPassword) {
      targetAdmin.password = await bcryptjs.hash(newPassword, 10);
    }

    await targetAdmin.save();

    res.status(200).json({
      success: true,
      message: "Admin updated successfully",
    });
  } catch (error) {
    console.log("Error in updateAdmin ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Suppression d'un administrateur
export const deleteAdmin = async (req, res) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    const targetAdmin = await Admin.findByIdAndDelete(req.params.id);
    if (!targetAdmin) {
      return res
        .status(404)
        .json({ success: false, message: "Admin not found" });
    }

    res.status(200).json({
      success: true,
      message: "Admin deleted successfully",
    });
  } catch (error) {
    console.log("Error in deleteAdmin ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Bloquer un administrateur
export const blockAdmin = async (req, res) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    const targetAdmin = await Admin.findById(req.params.id);
    if (!targetAdmin) {
      return res
        .status(404)
        .json({ success: false, message: "Admin not found" });
    }

    targetAdmin.isBlocked = true;
    await targetAdmin.save();

    res.status(200).json({
      success: true,
      message: "Admin blocked successfully",
    });
  } catch (error) {
    console.log("Error in blockAdmin ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Débloquer un administrateur
export const unblockAdmin = async (req, res) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    const targetAdmin = await Admin.findById(req.params.id);
    if (!targetAdmin) {
      return res
        .status(404)
        .json({ success: false, message: "Admin not found" });
    }

    targetAdmin.isBlocked = false;
    await targetAdmin.save();

    res.status(200).json({
      success: true,
      message: "Admin unblocked successfully",
    });
  } catch (error) {
    console.log("Error in unblockAdmin ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Récupérer tous les administrateurs
export const getAllAdmins = async (req, res) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }
    const admins = await Admin.find({ isSuperAdmin: false }).select(
      "-password -tokens"
    );

    res.status(200).json({
      success: true,
      data: admins,
    });
  } catch (error) {
    console.log("Error in getAllAdmins ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Récupérer un administrateur par ID
export const getAdminById = async (req, res) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    const targetAdmin = await Admin.findById(req.params.id).select(
      "-password -tokens"
    );
    if (!targetAdmin) {
      return res
        .status(404)
        .json({ success: false, message: "Admin not found" });
    }

    res.status(200).json({
      success: true,
      data: targetAdmin,
    });
  } catch (error) {
    console.log("Error in getAdminById ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Création d'un super administrateur de base
export const createSuperAdmin = async (req, res) => {
  const { email, password, firstName, lastName, phone } = req.body;

  try {
    if (!email || !password || !firstName || !lastName || !phone) {
      throw new Error("All fields are required");
    }

    const adminAlreadyExists = await Admin.findOne({ email });
    if (adminAlreadyExists) {
      return res
        .status(409)
        .json({ success: false, message: "Admin already exists" });
    }

    const hashedPassword = await bcryptjs.hash(password, 10);

    let superAdmin = new Admin({
      email,
      password: hashedPassword,
      firstName,
      lastName,
      phone,
      isSuperAdmin: true,
    });
    await superAdmin.save();
    const accessToken = generateAuthToken(superAdmin);

    res.status(201).json({
      success: true,
      message: "Super admin created successfully",
      accessToken,
    });
  } catch (error) {
    console.log("Error in createSuperAdmin ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};

// Suppression d'un super administrateur
export const deleteSuperAdmin = async (req, res) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin || !admin.isSuperAdmin) {
      return res.status(403).json({
        success: false,
        message: "Action interdite : Vous devez être un super admin.",
      });
    }

    const targetAdmin = await Admin.findById(req.params.id);
    if (!targetAdmin || !targetAdmin.isSuperAdmin) {
      return res
        .status(404)
        .json({ success: false, message: "Super admin not found" });
    }

    await Admin.findByIdAndDelete(req.params.id);

    res.status(200).json({
      success: true,
      message: "Super admin deleted successfully",
    });
  } catch (error) {
    console.log("Error in deleteSuperAdmin ", error);
    res.status(400).json({ success: false, message: error.message });
  }
};
