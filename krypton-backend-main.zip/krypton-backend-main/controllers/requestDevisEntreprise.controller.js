import { Devis } from "../models/requestDevis.model.js";

export const createDevisEntreprise = async (req, res) => {
  const {
    fullName,
    phone,
    email,
    nomEntreprise,
    secteurActivite,
    typeProduit,
    typePresentation,
    nombreEpisode,
    frequence,
    nmbreSemaine,
    nmbreMois,
  } = req.body;

  // Vérification des champs requis
  if (
    !fullName ||
    !phone ||
    !email ||
    !nomEntreprise ||
    !secteurActivite ||
    !typeProduit ||
    !typePresentation ||
    !nombreEpisode ||
    !frequence ||
    !nmbreSemaine ||
    !nmbreMois
  ) {
    return res.status(400).json({
      success: false,
      message: "Tous les champs requis doivent être remplis",
    });
  }

  try {
    const devis = new Devis({
      fullName,
      phone,
      email,
      nomEntreprise,
      secteurActivite,
      typeProduit,
      typePresentation,
      nombreEpisode,
      frequence,
      nmbreSemaine,
      nmbreMois,
      quotationType: "business",
    });

    await devis.save();

    res.status(201).json({
      success: true,
      message: "Formulaire d'enregistrement créé avec succès",
    });
  } catch (error) {
    console.log(error);

    res.status(500).json({ success: false, message: "Erreur serveur" });
  }
};

export const getDevisEntreprise = async (req, res) => {
  try {
    const devis = await Devis.find({ quotationType: "business" });

    if (!devis || devis.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No devis found",
      });
    }

    res.status(200).json({
      success: true,
      devis,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: "Server error" });
  }
};
