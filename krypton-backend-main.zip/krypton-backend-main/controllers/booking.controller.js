import { Booking } from "../models/booking.model.js";
import { User } from "../models/user.model.js";
import jwt from "jsonwebtoken";

export const createBooking = async (req, res) => {
  console.log(req.body);
  const {
    formula,
    sessionDuration,
    selectedDecor,
    selectedDate,
    timeSlot,
    peopleNumber,
    transactionId,
  } = req.body;

  if (
    !formula ||
    !sessionDuration ||
    !selectedDecor ||
    !selectedDate ||
    !timeSlot ||
    !peopleNumber ||
    !transactionId
  ) {
    return res.status(400).json({
      success: false,
      message: "All required fields must be filled",
    });
  }

  try {
    const token = req.headers["authorization"];

    if (!token) {
      return res.status(401).json({ message: "No token provided" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    console.log(decodedToken);

    const userdata = await User.findById(decodedToken._id);

    if (!userdata) {
      return res.status(404).json({ message: "User not found" });
    }

    const validToken = userdata.tokens.some((t) => t.accessToken === token);

    if (!validToken) {
      return res.status(401).json({ message: "Invalid access token" });
    }

    const booking = new Booking({
      userId: userdata._id,
      formula,
      sessionDuration,
      selectedDecor,
      selectedDate,
      timeSlot,
      peopleNumber,
      transactionId,
    });

    await booking.save();

    res.status(201).json({
      success: true,
      message: "Booking created successfully",
    });
  } catch (error) {
    console.error("Error in createBooking ", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const getUserBookings = async (req, res) => {
  try {
    const authHeader = req.headers["authorization"];

    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];
    console.log("token", token);

    if (!token) {
      return res.status(401).json({ message: "Invalid token format" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const userdata = await User.findById(decodedToken._id);

    if (!userdata) {
      return res.status(404).json({ message: "User not found" });
    }

    const bookings = await Booking.find({ userId: userdata._id });

    res.status(200).json({
      success: true,
      bookings: bookings.length > 0 ? bookings : [],
    });
  } catch (error) {
    console.error("Error in getUserBookings ", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

//  Ceci est pour dashboard admin
export const getUserBookingsByAdmin = async (req, res) => {
  try {
    const { userId } = req.params;
    const userdata = await User.findById(userId);

    if (!userdata) {
      return res.status(404).json({ message: "User not found" });
    }

    const bookings = await Booking.find({ userId: userdata._id });

    res.status(200).json({
      success: true,
      bookings: bookings.length > 0 ? bookings : [],
    });
  } catch (error) {
    console.error("Error in getUserBookings ", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

//  Ceci est pour dashboard admin
export const getBookingByIdByUserId = async (req, res) => {
  try {
    const { bookingId, userId } = req.params;
    const userdata = await User.findById(userId);

    if (!userdata) {
      return res.status(404).json({ message: "User not found" });
    }

    const booking = await Booking.findOne({
      _id: bookingId,
      userId: userdata._id,
    });

    if (!booking) {
      return res
        .status(404)
        .json({ message: "Booking not found or unauthorized" });
    }

    res.status(200).json({
      success: true,
      booking,
    });
  } catch (error) {
    console.error("Error in getBookingById ", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const deleteBooking = async (req, res) => {
  try {
    const authHeader = req.headers["authorization"];

    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).json({ message: "Invalid token format" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const userdata = await User.findById(decodedToken._id);

    if (!userdata) {
      return res.status(404).json({ message: "User not found" });
    }

    const { bookingId } = req.params;

    const booking = await Booking.findOne({
      _id: bookingId,
      userId: userdata._id,
    });

    if (!booking) {
      return res
        .status(404)
        .json({ message: "Booking not found or unauthorized" });
    }

    await Booking.deleteOne({ _id: bookingId });

    res.status(200).json({
      success: true,
      message: "Booking deleted successfully",
    });
  } catch (error) {
    console.error("Error in deleteBooking ", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const updateBooking = async (req, res) => {
  try {
    const authHeader = req.headers["authorization"];

    if (!authHeader) {
      return res.status(401).json({ message: "No token provided" });
    }

    const token = authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).json({ message: "Invalid token format" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    const userdata = await User.findById(decodedToken._id);

    if (!userdata) {
      return res.status(404).json({ message: "User not found" });
    }

    const { bookingId } = req.params;
    const updatedData = req.body;

    const booking = await Booking.findOne({
      _id: bookingId,
      userId: userdata._id,
    });

    if (!booking) {
      return res
        .status(404)
        .json({ message: "Booking not found or unauthorized" });
    }

    Object.assign(booking, updatedData);

    await booking.save();

    res.status(200).json({
      success: true,
      message: "Booking updated successfully",
      booking,
    });
  } catch (error) {
    console.error("Error in updateBooking ", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const unavailableSlot = async (req, res) => {
  try {
    const { date } = req.params; // Get the date from request parameters

    // Sample unavailabilities data
    const unavailabilitiesData = {
      "28-9-2024": [
        "07:00",
        "07:30",
        "08:00",
        "08:30",
        "09:00",
        "09:30",
        "10:00",
        "10:30",
        "11:00",
        "11:30",
        "12:00",
        "12:30",
        "13:00",
        "13:30",
        "14:00",
        "14:30",
        "15:00",
        "15:30",
        "16:00",
        "16:30",
        "17:00",
        "17:30",
        "18:00",
        "18:30",
        "19:00",
        "19:30",
        "20:00",
        "20:30",
        "21:00",
        "21:30",
        "22:00",
      ],
      "21-9-2024": [
        "7:00",
        "7:30",
        "8:00",
        "8:30",
        "9:00",
        "9:30",
        "10:00",
        "10:30",
        "11:00",
        "11:30",
        "12:00",
        "12:30",
        "13:00",
        "13:30",
        "14:00",
        "14:30",
        "15:00",
        "15:30",
        "16:00",
        "16:30",
        "17:00",
        "17:30",
        "18:00",
        "18:30",
        "19:00",
        "19:30",
        "20:00",
        "20:30",
        "21:00",
        "21:30",
        "22:00",
      ],
      "22-9-2024": [
        "7:00",
        "7:30",
        "8:00",
        "8:30",
        "9:00",
        "9:30",
        "10:00",
        "10:30",
        "11:00",
        "11:30",
        "12:00",
        "12:30",
        "13:00",
        "13:30",
        "14:00",
        "14:30",
        "15:00",
        "15:30",
        "16:00",
        "16:30",
        "17:00",
        "17:30",
        "18:00",
        "18:30",
        "19:00",
        "19:30",
        "20:00",
        "20:30",
        "21:00",
        "21:30",
        "22:00",
        "22:30",
      ],
    };

    // Retrieve unavailabilities for the requested date or return an empty array
    const dateUnavailabilities = unavailabilitiesData[date] || [];

    res.status(200).json({
      success: true,
      dateUnavailabilities,
    });
  } catch (error) {
    // Handle any unexpected errors
    console.error("Error retrieving unavailable slots:", error);

    res.status(500).json({
      success: false,
      message: "An error occurred while retrieving unavailable slots.",
      error: error.message, // Optional: provide more details if needed
    });
  }
};
