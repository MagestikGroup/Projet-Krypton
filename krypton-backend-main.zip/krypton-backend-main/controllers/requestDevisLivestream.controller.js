import { User } from "../models/user.model.js";
import { Devis } from "../models/requestDevis.model.js";
import { sendDevisEmail } from "../mailJet/emails.js";

export const createDevis = async (req, res) => {
  const {
    fullName,
    phone,
    email,
    secteurActivite,
    livestream,
    other,
    dureeEvenement,
    nombrePersonnes,
    nombreIntervenantsDistant,
    typeCanal,
    typeEvenement,
    ifOther,
    date,
    descriptionEvenement,
    nomEntreprise,
  } = req.body;
  if (
    !fullName ||
    !phone ||
    !email ||
    !secteurActivite ||
    !dureeEvenement ||
    !nombrePersonnes ||
    !nombreIntervenantsDistant ||
    !typeCanal ||
    !typeEvenement ||
    !date ||
    !descriptionEvenement ||
    !nomEntreprise
  ) {
    return res.status(400).json({
      success: false,
      message: "Tous les champs requis doivent être remplis",
    });
  }
  try {
    const devis = new Devis({
      fullName,
      phone,
      email,
      secteurActivite,
      livestream,
      other,
      dureeEvenement,
      nombrePersonnes,
      nombreIntervenantsDistant,
      typeCanal,
      typeEvenement,
      ifOther,
      date,
      descriptionEvenement,
      nomEntreprise,
      quotationType: "livestream",
    });

    await devis.save();

    res.status(201).json({
      success: true,
      message: "Devis created successfully",
    });
  } catch (error) {
    console.log("Error in createDevis", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const getDevis = async (req, res) => {
  const { devisId } = req.params;

  try {
    const devis = await Devis.findById(devisId);

    if (!devis) {
      return res.status(404).json({
        success: false,
        message: "Devis not found",
      });
    }

    res.status(200).json({
      success: true,
      devis,
    });
  } catch (error) {
    console.log("Error in getDevis", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

// export const getDevisByUserIdAndDevisId = async (req, res) => {
//   const { userId, devisId } = req.params;

//   try {
//     const devis = await Devis.findOne({ _id: devisId, userId }).populate({
//       path: "userId",
//       select: "firstName phone _id",
//     });

//     if (!devis) {
//       return res.status(404).json({
//         success: false,
//         message: "Devis not found for this user",
//       });
//     }

//     res.status(200).json({
//       success: true,
//       devis,
//     });
//   } catch (error) {
//     console.log("Error in getDevisByUserIdAndDevisId", error);
//     res.status(500).json({ success: false, message: "Server error" });
//   }
// };

export const getAllDevis = async (req, res) => {
  try {
    const devis = await Devis.find({ quotationType: "livestream" });

    if (!devis || devis.length === 0) {
      return res.status(404).json({
        success: false,
        message: "No devis found",
      });
    }

    res.status(200).json({
      success: true,
      devis,
    });
  } catch (error) {
    console.log("Error in getAllDevis", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};

export const deleteDevis = async (req, res) => {
  const { devisId } = req.params;

  try {
    const devis = await Devis.findByIdAndDelete(devisId);

    if (!devis) {
      return res.status(404).json({
        success: false,
        message: "Devis not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Devis deleted successfully",
    });
  } catch (error) {
    console.log("Error in deleteDevis", error);
    res.status(500).json({ success: false, message: "Server error" });
  }
};
