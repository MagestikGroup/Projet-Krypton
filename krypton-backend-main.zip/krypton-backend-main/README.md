# Serveur d'API Krypton

## Table des Matières
1. [Aperçu](#aperçu)
2. [Prérequis](#prérequis)
3. [Guide d'installation](#guide-dinstallation)
4. [Lancer l'application](#lancer-lapplication)
5. [Utilisation](#utilisation)
6. [Dépannage](#dépannage)
7. [Ressources supplémentaires](#ressources-supplémentaires)

---

## 1- Aperçu
Ce projet constitue le Backend fournissant les services d'API nécessaires à l'application web Krypton.

CetteServeur d'API backend est construite avec Node.js et le framework Express. Elle gère les requêtes HTTP et les interactions côté base de données, la collecte, le traitement et la persistence des donnée côté serveur .

Ce guide fouri des instructions détaillées pour installer Node.js, configurer le projet, et lancer l'application en local.

---


# Guide de démarrage 

## 2- Prérequis

Avant de démarrer, assurez-vous d'avoir installé Node.js et npm (Node Package Manager) sur votre machine.

### Installation de Node.js

1. Rendez-vous sur le site officiel de Node.js : [https://nodejs.org](https://nodejs.org)
2. Téléchargez la version LTS recommandée pour votre système d'exploitation.
3. Suivez les instructions d'installation.

Une fois l'installation terminée, vérifiez que Node.js et npm sont correctement installés en exécutant les commandes suivantes dans votre terminal :

```bash
node -v
npm -v
```

Ces commandes devraient renvoyer les versions respectives de Node.js et npm installées.

## Clonage du projet

Clonez ce dépôt sur votre machine locale :

```bash
git clone https://github.com/MagestikGroup/krypton-backend.git
```

Accédez au répertoire du projet cloné :

```bash
cd krypton-backend
```

## Installation des dépendances

Une fois dans le répertoire du projet, exécutez la commande suivante pour installer les dépendances nécessaires :

```bash
npm install
```

Cette commande installera tous les packages nécessaires spécifiés dans le fichier `package.json`.

## Configuration

Renomer le fichier `.env.example` en `.env` :


Mettez à jour les valeurs des variables d'environnement qui vous sont transmises.

## Lancement de l'application

Pour démarrer l'application en mode développement, exécutez :

```bash
npm run dev
```

Cela démarrera l'application en utilisant en HotReload, qui surveille les modifications des fichiers et redémarre automatiquement le serveur.


## Accès à l'application

Par défaut, l'application sera accessible à l'adresse suivante :

```
http://localhost:8000
```

