import {
  PASSWORD_RESET_REQUEST_TEMPLATE,
  PASSWORD_RESET_SUCCESS_TEMPLATE,
  VERIFICATION_EMAIL_TEMPLATE,
  CONTACT_REQUEST_TEMPLATE,
  Devis_REQUEST_TEMPLATE,
  REGISTER_FORM_REQUEST_TEMPLATE,
} from "./emailTemplates.js";
import { mailjetClient, sender } from "./mailjet.config.js";

// Send Verification Email
export const sendVerificationEmail = async (email, verificationToken) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            Subject: "Verify your email",
            HTMLPart: VERIFICATION_EMAIL_TEMPLATE.replace(
              "{verificationCode}",
              verificationToken
            ),
            CustomID: "EmailVerification",
          },
        ],
      });

    console.log("Email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending verification email`, error);
    throw new Error(`Error sending verification email: ${error.message}`);
  }
};

// Send Welcome Email
export const sendWelcomeEmail = async (email, firstName) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            TemplateID: 123456, // Replace with your actual Mailjet template ID
            TemplateLanguage: true,
            Subject: "Welcome!",
            Variables: {
              company_info_firstName: "Auth Company",
              firstName: firstName,
            },
          },
        ],
      });

    console.log("Welcome email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending welcome email`, error);
    throw new Error(`Error sending welcome email: ${error.message}`);
  }
};

// Send Password Reset Email
export const sendPasswordResetEmail = async (email, resetURL) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            Subject: "Reset your password",
            HTMLPart: PASSWORD_RESET_REQUEST_TEMPLATE.replace(
              "{resetURL}",
              resetURL
            ),
            CustomID: "PasswordReset",
          },
        ],
      });

    console.log("Password reset email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending password reset email`, error);
    throw new Error(`Error sending password reset email: ${error.message}`);
  }
};

// Send Password Reset Success Email
export const sendResetSuccessEmail = async (email) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            Subject: "Password Reset Successful",
            HTMLPart: PASSWORD_RESET_SUCCESS_TEMPLATE,
            CustomID: "PasswordResetSuccess",
          },
        ],
      });

    console.log("Password reset success email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending password reset success email`, error);
    throw new Error(
      `Error sending password reset success email: ${error.message}`
    );
  }
};

// Send contact Email

export const sendContactEmail = async (email, resetURL) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            Subject: "Reset your password",
            HTMLPart: CONTACT_REQUEST_TEMPLATE.replace("{resetURL}", resetURL),
            CustomID: "PasswordReset",
          },
        ],
      });

    console.log("Password reset email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending password reset email`, error);
    throw new Error(`Error sending password reset email: ${error.message}`);
  }
};

// Send devis Email

export const sendDevisEmail = async (email, resetURL) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            Subject: "Reset your password",
            HTMLPart: Devis_REQUEST_TEMPLATE.replace("{resetURL}", resetURL),
            CustomID: "PasswordReset",
          },
        ],
      });

    console.log("Password reset email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending password reset email`, error);
    throw new Error(`Error sending password reset email: ${error.message}`);
  }
};

// Send register form Email

export const sendRegisterFormEmail = async (email, resetURL) => {
  const recipient = [{ Email: email }];

  try {
    const request = await mailjetClient
      .post("send", { version: "v3.1" })
      .request({
        Messages: [
          {
            From: sender,
            To: recipient,
            Subject: "Reset your password",
            HTMLPart: REGISTER_FORM_REQUEST_TEMPLATE.replace(
              "{resetURL}",
              resetURL
            ),
            CustomID: "PasswordReset",
          },
        ],
      });

    console.log("Password reset email sent successfully", request.body);
  } catch (error) {
    console.error(`Error sending password reset email`, error);
    throw new Error(`Error sending password reset email: ${error.message}`);
  }
};
