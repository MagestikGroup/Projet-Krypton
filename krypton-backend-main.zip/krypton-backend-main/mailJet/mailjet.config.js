import Mailjet from "node-mailjet";
import dotenv from "dotenv";

dotenv.config();

export const mailjetClient = Mailjet.apiConnect(
  process.env.MAILJET_API_KEY,
  process.env.MAILJET_API_SECRET
);

export const sender = {
  email: "yves.kokou.10@gmail.com",
  name: "Yves Kokou",
};
