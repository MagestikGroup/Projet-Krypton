import jwt from "jsonwebtoken";
const User = require("../models/user.model.js");

const auth = async (req, res, next) => {
  try {
    const token = req.headers.authorization;

    if (!token) {
      return res.status(401).json({ message: "Token not provided" });
    }

    const decodedToken = jwt.verify(token, process.env.JWT_SECRET);

    if (!decodedToken) {
      return res.status(401).json({ message: "go to login page" });
    }

    const user = await User.findOne({
      userID: decodedToken._id,
      "tokens.token": token,
    });

    if (!user) {
      return res.status(401).json({ message: "go to login page" });
    }

    const userResponse = {
      fullName: user.fullName,
      email: user.email,
      accountStatus: user.accountStatus,
      subscription: user.subscription,
    };

    req.token = token;
    req.user = userResponse;
    req.fullUser = user;
    next();
  } catch (err) {
    return res.status(401).json({ message: "go to login page" });
  }
};

export default auth;
