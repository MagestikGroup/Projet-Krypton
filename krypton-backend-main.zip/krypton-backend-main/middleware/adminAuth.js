import jwt from "jsonwebtoken";
import Admin from "../models/admin.model.js";

export const isAuthenticated = async (req, res, next) => {
  try {
    const token = req.header("Authorization").replace("Bearer ", "");
    console.log("Received Token: ", token);

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    console.log("Decoded Token: ", decoded);

    // Recherchez l'admin avec l'ID et le token
    const admin = await Admin.findOne({
      _id: decoded._id,
      "tokens.accessToken": token,
    });

    if (!admin || admin.isBlocked) {
      return res.status(401).json({ message: "Authentication failed" });
    }

    req.adminId = admin._id;
    req.token = token;

    next();
  } catch (error) {
    console.error("Error in isAuthenticated: ", error);
    res.status(401).json({ message: "Please authenticate" });
  }
};

export const isSuperAdmin = async (req, res, next) => {
  try {
    const admin = await Admin.findById(req.adminId);
    if (!admin.isSuperAdmin) {
      return res
        .status(403)
        .json({ message: "Access denied: Super admin only" });
    }
    next();
  } catch (error) {
    res.status(401).json({ message: "Please authenticate ffff" });
  }
};
