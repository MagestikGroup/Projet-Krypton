export interface KTImageInputConfigInterface {
	hiddenClass: string;
}

export interface KTImageInputInterface {		
	remove(): void;
}