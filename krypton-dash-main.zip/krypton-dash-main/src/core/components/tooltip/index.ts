export { KTTooltip } from './tooltip';
export type { KTTooltipConfigInterface, KTTooltipInterface } from './types';