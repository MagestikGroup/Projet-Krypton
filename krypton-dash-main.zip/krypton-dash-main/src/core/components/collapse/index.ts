export { KTCollapse } from './collapse';
export type { KTCollapseConfigInterface, KTCollapseInterface } from './types';
